VTDManager v1.3
===============
Copyright (c) 2002-2003 Jansoft
jan.stuchlik@email.cz
http://jansoft.aquasoft.cz


Description
-----------
This tool is used for managing VTD files.
You can create, load, view VTD files or "compile" it from XML file. 

Structure of XML file is documented in file VTDB.DTD. 


Changes
-------
v1.3
 - PDrawEx 1.7 
v1.2
 - locating of PDrawEx.dll in .;DLL;RES;Libraries;..;..\Misc;..\..\Misc
 - VTDB.DTD v1.3 :
	- INCLUDE tag
	- VTDBREC tag
 - renaming records
 - some visible improvements
 - binary and text preview
 - multiple textures support in manual and XML mode
 - division by zero bug found
v1.1
 - VTDB.DTD version 1.2
 - creating VTDb's
 - adding bitmaps
 - adding files
 - adding fonts
 - extracting to bitmap
v1.0
 - PowerDraw 3.0
 - Directx 9+ required
 - importing FNT v1, FNT v2
 - FONT and FONTBMP tag
 - deleting records
 - VTDB.DTD version 1.0
 - ! separated alpha channel and alpha key color cannot be used
v0.6
 - minor changes : Version and CoVersion information
 - bug with signature

To do
-----
* more parameters in export (format,colors,...)
