  PowerDraw v3.0 Pre-Release 3
  Written by Lifepower (lifepower@fromru.com)

 - Current release features experimental Software Rendering
 engine which requires only DirectX7.0 and emulates most of
 capabilities of TPowerDraw; use Hardware property of TPowerDraw
 to switch between 3D hardware and software renderer.

 This new set of completely re-written components provides
 new support for DirectX 9.0 and contains dozens of features.
 It also provides new & improved tools for VTDb managment and
 Win32 Font rendering (also, new tools don't need PDrawEx.dll). 
 The development of PowerDraw 3.0 is still  and progress and any 
 feedback would be appreciated. Note that TObjectEngine and help
 file are incomplete and are still in development.

 Installation:
  You may remove old PowerDraw 2.x first (although this is
  not strictly necessary, having both PowerDraw versions may
  cause compilation problems). For Delphi 5 users - you will
  get compilation errors with PowerDraw 3.0 which can be fixed
  by changing "types.pas" unit name to "windows.pas". 

 Minimal Requirements:
  1) DirectX 7.0 for Software Emulation, DirectX 9.0 for Hardware Acceleration
  2) Borland Delphi 5 or later
  3) 3D-compatible video card for Hardware Acceleration

 TPowerDraw Features:

  * PowerDraw Software Renderer (PSR ver1.0)
  * Direct3D 9.0 encapsulation
  * Texture Mapping, Flexible Rendering
  * Combinable Rendering Effects (add, multiply, etc.)
  * Rendering Transformation (scale, rotation, etc.)
  * Lost device managment & events
  * Buffered & cached rendering for high performance
  * Fast Graphics Primitives (rectangles, polygons, circles, etc.)
  * Pixel managment routines
  * 90% backward compatibility with PowerDraw 2.x
  * Lost device managment (requires TPowerTimer)
  
 TAGFImage Features:

  * Direct3D 9.0 texture encapsulation
  * Texture format flexible conversion with many supported formats
  * Pixel data low-level and high-level managment
  * Loading textures from VTDb, TStream or File (.bmp or .tga)
  * Image effects like grayscale, mirror, flip, etc.
   
 TPowerFont Features:

  * Different font color and styles (bold, italic, shadow, etc)
  * Various types of aligned font output
  * Efficient texture utilization for fast output
  * Font transformation (scale, spacing, etc)
  * Supports old PowerDraw2.x (ver1.0) format
  * New ver2.0 font format can be stored in VTDb for convenience
  * Multiply font color tags

 TVTDb Features:

  * LZW/LZS77 Data compression
  * 64-bit data encryption with global VTDb password
  * Record Types (Graphics, File, Font, etc)
  * Supports old VTDb ver1.0 format
  * Vector Record Table for fast record search
  * CRC32 and Header backup for reliable data storage
  * Multiple file signature for creating custom file formats
  
 TPowerTimer Features:

  * Frame Rate control with precise timing
  * Support real-time event for movement interpolation
  * Each rendering, processing or real-time part can be enabled or disabled
  * Execution control with overrun and underrun feedback
  * Application events provided - OnIdle, OnActivate and OnDeactivate

 TParticleEngine Features:

  * Particle indexing & ordering for high performance rendering
  * Invidiual particle positioning, velocity and acceleration
  * Multiply particle effects and animation parameters

 TObjectEngine Features:
  
  * Object ordering by ID
  * Invidual object methods can be overriden for programmer's convenience
  * Invidual object position / velocity and animation parameters
